1.Exceute the sql in below sequence.

a)Addon.txt (Execute On CLIMSPATCH)
b)PROC_UPLOAD_FILE_CLENUP.txt (Execute On CLIMSPATCH)
c)SP_UPDATE_PARTY_CAM_UPLOAD.txt (Execute On CLIMSPATCH)
d)SP_UPDATE_PARTY_CAM_UPLOAD_STA.txt  (Execute On CLIMSPATCH)
e)SP_Upload_transaction.txt (Execute On CLIMSPATCH)
f)SYNONYM_for_CLIMSAPP.txt (Execute On CLIMSAPP)
g)SYNONYM_for_CLIMSPATCH.txt (Execute On CLIMSPATCH)