1.Exceute the sql in below sequence.

a)SYNONYM_ROLLBACK_CLIMSAPP.txt (Execute On CLIMSAPP)
b)Rollback_Script.txt (Execute On CLIMSPATCH)
c)SP_Upload_transaction.txt (Execute On CLIMSPATCH)
d)PROC_UPLOAD_FILE_CLENUP.txt (Execute On CLIMSPATCH)